Task 1:
1. Run 'make'

Task 2:

1. Run 'make'

The answer to Task 2, Item 3 is contained in 3.txt

Task 3:

1. Run 'make'