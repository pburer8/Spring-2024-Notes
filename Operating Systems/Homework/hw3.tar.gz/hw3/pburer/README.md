# Instructions

Task 1:
1. Compile page.c
2. Run

Task 2:
1. Compile page.c
2. Run

Task 3:
1. Compile page.c
2. Run

Task 4:
Results in 4.pdf
To get code that generates results:
1. Compile page.c
2. Run

Task 5:
Results in 5.pdf
To get code that generates results:
1. Compile page.c
2. Run