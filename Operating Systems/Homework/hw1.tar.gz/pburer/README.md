Marie Burer's CS:3620 Homework 1 README

Instructions for task 1:

Step 1: open directory in terminal
Step 2: run 'make'
Step 3: run './shell'
Step 4: enjoy (there are dummy files to test certain functions on)

Instrutions for task 2:

Step 1: open directory in terminal
Step 2: run 'make'
Step 3: run './manager'
Step 4: enjoy

Instructions for task 3:

Dependencies:
python libraries: tkinter, subprocess, sys

Step 1: open directory in terminal
Step 2: run 'make'
Step 3: run 'python3 gui.py'
Step 4: enjoy